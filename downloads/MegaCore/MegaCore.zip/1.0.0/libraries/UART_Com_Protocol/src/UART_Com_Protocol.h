/*
 * UART_Com_Protocol.h
 *
 * Created: 12/11/2017 1:48:56 PM
 *  Author: LENOVO
 */ 


#ifndef UART_COM_PROTOCOL_H_
#define UART_COM_PROTOCOL_H_

#define START_BYTE 0b10101010
#define STOP_BYTE 0b01010101
void UART0_init(long);
void UART1_init(long);
void UART0_send_byte(char);
void UART1_send_byte(char);
void send_struct_UART0(void);
void send_struct_UART1(void);
void send_start_byte_UART0(void);
void send_stop_byte_UART0(void);
void send_start_byte_UART1(void);
void send_stop_byte_UART1(void);



#endif /* UART_COM_PROTOCOL_H_ */