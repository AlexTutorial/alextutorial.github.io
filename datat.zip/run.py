# Pygame шаблон - скелет для нового проекта Pygame
import pygame
import random

FPS = 30

WIDTH = 360
HEIGHT = 480

# Задаем цвета
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)

# Создаем игру и окно
pygame.init()
pygame.mixer.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("My Game")
clock = pygame.time.Clock()


class Player:
    def __init__(self):
        self.x_pos = 50
        self.y_pos = 50
        self.x = 100
        self.y = 200
        self.r = pygame.Rect(self.x_pos, self.y_pos, self.x, self.y)

    def draw(self):
        self.r = pygame.Rect(self.x_pos, self.y_pos, self.x, self.y)
        pygame.draw.rect(screen, (255, 0, 0), self.r, 0)


player = Player()


def update_game():
    player.x = random.randint(50, 150)
    player.y = random.randint(150, 250)


def draw_screen():
    player.draw()


# Цикл игры
running = True
while running:
    # Держим цикл на правильной скорости
    clock.tick(FPS)
    # Ввод процесса (события)
    for event in pygame.event.get():
        # check for closing window
        if event.type == pygame.QUIT:
            running = False

    # Обновление
    update_game()
    # Рендеринг
    screen.fill(BLACK)
    draw_screen()
    # После отрисовки всего, переворачиваем экран
    pygame.display.flip()

pygame.quit()
